
#include <iostream>
#include "User.h"

using namespace std;

int User::n_user = 0;

// ctor, parameter: nama pengguna
User::User(char *nm)
{
    name = new char[strlen(nm) + 1];
    strcpy(name, nm);
    num_of_favourite_music = 0;
    music_list = new char *[1000];
    n_user++;
}

// cctor
User::User(const User &other)
{
    name = new char[strlen(other.getName()) + 1];
    strcpy(name, other.getName());
    num_of_favourite_music = other.getNumOfFavouriteMusic();
    music_list = new char *[1000];
    for (int i = 0; i < num_of_favourite_music; i++)
    {
        music_list[i] = new char[strlen(other.music_list[i])];
        strcpy(music_list[i], other.music_list[i]);
    }
    n_user++;
}

// dtor
// selain implementasi, print juga "User <nama user> deleted<endl>"
// Contoh:
// User A deleted
//
User::~User()
{
    cout << "User " << name << " deleted" << endl;
    delete[] name;
    delete[] music_list;
}

// Asumsi: musik unik, parameter: judul musik
void User::addFavouriteMusic(char *title)
{
    music_list[num_of_favourite_music] = new char[strlen(title) + 1];
    strcpy(music_list[num_of_favourite_music], title);
    num_of_favourite_music++;
}
void User::deleteFavouriteMusic(char *title)
{
    int idx;
    bool found = false;

    for (int i = 0; i < num_of_favourite_music; i++)
    {
        if (strcmp(music_list[i], title) == 0)
        {
            idx = i;
            found = true;
            break;
        }
    }
    if (found)
    {
        // still not sure
        char *a = music_list[idx];
        for (int i = idx; i < num_of_favourite_music - 1; i++)
        {
            music_list[i] = music_list[i + 1];
        }
        delete[] a;
        delete[] music_list[num_of_favourite_music - 1];
    }
    num_of_favourite_music--;
}

void User::setName(char *nm)
{
    name = new char[strlen(nm) + 1];
    strcpy(name, nm);
}
char *User::getName() const { return name; }
int User::getNumOfFavouriteMusic() const { return num_of_favourite_music; }

// format print:
// <No>. <Judul musik><endl>
// contoh:
// 1. Starship - Nicki Minaj
// 2. To Be Human - Sia, Labrinth
//
// jika tidak ada musik, print: "No music in your favourite list<endl>"
void User::viewMusicList() const
{
    if (num_of_favourite_music == 0)
    {
        cout << "No music in your favourite list" << endl;
    }
    else
    {
        for (int i = 0; i < num_of_favourite_music; i++)
        {
            cout << i + 1 << ". " << music_list[i] << endl;
        }
    }
}

int User::getNumOfUser()
{
    return n_user;
}

// char *name;
// int num_of_favourite_music; // jumlah musik yang ada pada music_list
// char **music_list;          // daftar judul musik
// static int n_user;
