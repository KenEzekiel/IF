
#include "User.h"
#include "ArtistUser.h"
#include <iostream>

using namespace std;

int ArtistUser::num_of_artist = 0;

// ctor, parameter: nama pengguna
ArtistUser::ArtistUser(char *nm) : User(nm)
{
    num_of_music_uploaded = 0;
    uploaded_music_list = new char *[1000];
    num_of_artist++;
}

// cctor
ArtistUser::ArtistUser(const ArtistUser &other) : User(other)
{
    num_of_music_uploaded = other.getNumOfMusicUploaded();
    uploaded_music_list = new char *[1000];

    for (int i = 0; i < num_of_music_uploaded; i++)
    {
        uploaded_music_list[i] = new char[strlen(other.uploaded_music_list[i]) + 1];
        strcpy(uploaded_music_list[i], other.uploaded_music_list[i]);
    }
    num_of_artist++;
}

// dtor
// selain implementasi, print juga "Artist user <nama user> deleted"
// Contoh:
// Artist user A deleted
ArtistUser::~ArtistUser()
{
    cout << "Artist user " << name << " deleted" << endl;
    delete[] uploaded_music_list;
}

// Asumsi: musik unik, parameter: judul musik
void ArtistUser::uploadMusic(char *title)
{
    uploaded_music_list[num_of_music_uploaded] = new char[strlen(title) + 1];
    strcpy(uploaded_music_list[num_of_music_uploaded], title);
    num_of_music_uploaded++;
}
void ArtistUser::deleteUploadedMusic(char *title)
{
    int idx;
    bool found = false;

    for (int i = 0; i < num_of_music_uploaded; i++)
    {
        if (strcmp(uploaded_music_list[i], title) == 0)
        {
            idx = i;
            found = true;
            break;
        }
    }
    if (found)
    {
        // still not sure
        delete[] uploaded_music_list[idx];
        for (int i = idx; i < num_of_music_uploaded - 1; i++)
        {
            uploaded_music_list[i] = uploaded_music_list[i + 1];
        }
        delete[] uploaded_music_list[num_of_music_uploaded - 1];
    }
    num_of_music_uploaded--;
}

// format print:
// <No>. <Judul musik><endl>
// contoh:
// 1. Starship - Nicki Minaj
// 2. To Be Human - Sia, Labrinth
//
// jika tidak ada musik, print: "No music uploaded<endl>"
void ArtistUser::viewUploadedMusicList() const
{
    if (num_of_music_uploaded == 0)
    {
        cout << "No music in uploaded" << endl;
    }
    else
    {
        for (int i = 0; i < num_of_music_uploaded; i++)
        {
            cout << i + 1 << ". " << uploaded_music_list[i] << endl;
        }
    }
}
int ArtistUser::getNumOfMusicUploaded() const { return num_of_music_uploaded; }
int ArtistUser::getNumOfArtist()
{
    return num_of_artist;
}

// int num_of_music_uploaded; // jumlah musik dalam uploaded_music_list
// char **uploaded_music_list;
// static int num_of_artist;
