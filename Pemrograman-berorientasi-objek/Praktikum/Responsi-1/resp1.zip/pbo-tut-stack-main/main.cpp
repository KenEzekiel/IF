#include <iostream>
#include "Stack.hpp"
using namespace std;

int main() {
  cout << "punten bang" << endl;

  Stack s;
  cout << s.pop() << '\n';
  return 0;
}
