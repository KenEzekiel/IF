#include <iostream>

using namespace std;

class halo {
	
}

int main() {
	cout << "Hello world!" << endl;
	return 0;
}
