#include "A.hpp"

int main() {
	A a('1');
	A b('2');
	A c(a);
	a = b;
	a.show();
}