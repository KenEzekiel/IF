#include "Hello.h"
#include <iostream>
using namespace std;

// Hello constructor
Hello::Hello() {
  cout << "Hello World!!" << endl;
}