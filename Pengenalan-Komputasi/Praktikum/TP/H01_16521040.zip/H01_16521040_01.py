# NIM/Nama  : 16521040/Kenneth Ezekiel Suprantoni
# Tanggal   : 04/10/2021
# Deskripsi : Buatlah sebuah program yang menuliskan ”Hello, World!” ke layar.

# Program menuliskan "Hello, World!" ke layar
# Algoritma
print("Hello, World!")