# NIM/Nama : 16521040/Kenneth Ezekiel
# Tanggal : 12/10/2021
# Deskripsi : Program yang menerima nilai N dan menuliskan 1 sampai N

# Algoritma
N = int(input("Masukkan N: "))

for i in range(N):
    print(i+1, end=" ")