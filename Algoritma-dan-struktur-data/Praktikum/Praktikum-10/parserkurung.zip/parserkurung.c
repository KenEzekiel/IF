#include "stacklinked.h"
#include "boolean.h"
#include <stdio.h>

int main()
{
	Stack s;
	ElType val;
	boolean check = true;
	CreateStack(&s);

	int sik = 0;
	int bul = 0;
	int teg = 0;
	int kur = 0;
	int seg = 0;

	int len = 0;
	int max = 0;
	char cc;

	scanf("%c", &cc);

	while (cc != '.') {
		if (cc == '[') {
			push(&s, 0);
			len++;
			DisplayStack(s);
			printf("\n");
			sik++;
		} else if (cc == ']') {
			if (!isEmpty(s) && TOP(s) == 0){
				pop(&s, &val);
				len--;
			} else {
				check = false;
			}
			DisplayStack(s);
			printf("\n");
		} else if (cc == '(') {
			push(&s, 1);
			len++;
			DisplayStack(s);
			printf("\n");
			bul++;
		} else if (cc == ')') {
			if (!isEmpty(s) && TOP(s) == 1){
				pop(&s, &val);
				len--;
			} else {
				check = false;	
			}
			DisplayStack(s);
			printf("\n");
		} else if (cc == '|' && (isEmpty(s) || TOP(s) != 2)) {
			push(&s, 2);
			len++;
			DisplayStack(s);
			printf("\n");
			teg++;
		} else if (cc == '|' && !isEmpty(s) && TOP(s) == 2) {
			pop(&s, &val);
			len--;
			DisplayStack(s);
			printf("\n");
		} else if (cc == '{') {
			push(&s, 3);
			len++;
			DisplayStack(s);
			printf("\n");
			kur++;
		} else if (cc == '}') {
			if (!isEmpty(s) && TOP(s) == 3){
				pop(&s, &val);
				len--;
			} else {
				check = false;
			}
			DisplayStack(s);
			printf("\n");
		} else if (cc == '<') {
			push(&s, 4);
			len++;
			DisplayStack(s);
			printf("\n");
			seg++;
		} else if (cc == '>') {
			if (!isEmpty(s) && TOP(s) == 4){
				pop(&s, &val);
				len--;
			} else {
				check = false;
			}
			DisplayStack(s);
			printf("\n");
		}
		
		if (max < len){
			max = len;
		}
		else {
			max = max;
		}

		scanf("%c", &cc);
	}

	if (!check || !isEmpty(s)) {
		printf("kurung tidak valid\n");
	} else {
		printf("kurung valid\n");
		printf("[%d] (%d) |%d| {%d} <%d>\n", sik, bul, teg, kur, seg);
		printf("MAX %d\n", max);
	}

	return 0;
}