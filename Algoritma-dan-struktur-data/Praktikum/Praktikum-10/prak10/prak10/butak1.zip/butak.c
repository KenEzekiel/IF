#include "charmachine.h"
#include "queuelinked.h"
#include <stdio.h>

boolean isElHomogen(Queue q) {
	// KAMUS LOKAL
    Address p = ADDR_HEAD(q);
    ElType info = HEAD(q);
    ElType val;
    boolean homogen = true;
    // ALGORITMA
    if (!isEmpty(q)) {
        while (p != NULL && homogen)
        {
            val = INFO(p);
            if (info != val) {
            	homogen = false;
            }
            p = NEXT(p);
        }
    }
    
    return homogen;
}

int main() {
	Queue qpref, qno, qmakanan;
	boolean udahKoma = false;
	int nomor = 1;
	ElType mhs, mkn;
	int tempno;
	boolean condition = true;


	CreateQueue(&qpref);
	CreateQueue(&qno);
	CreateQueue(&qmakanan);


	START();
	while (!EOP) {

		if (!udahKoma && currentChar == ',') {
			udahKoma = true;
		} else if (!udahKoma) {
			if(currentChar == 'B') {
				enqueue(&qpref, 0);
				enqueue(&qno, nomor);
				nomor++;
			} 
			if(currentChar == 'K') {
				enqueue(&qpref, 1);
				enqueue(&qno, nomor);
				nomor++;
			}

		} else {
			if(currentChar == 'B') {
				enqueue(&qmakanan, 0);
			} 
			if(currentChar == 'K') {
				enqueue(&qmakanan, 1);
			}
		}

		ADV();
	}
	
	
	while (condition) {
		//printf("\n");
		//DisplayQueue(qpref);
		//DisplayQueue(qno);
		//DisplayQueue(qmakanan);
		dequeue(&qpref, &mhs);
		dequeue(&qno, &tempno);

		if(mhs == HEAD(qmakanan)) {
			dequeue(&qmakanan, &mkn);
			printf("%d -> ", tempno);
			if(mkn == 0) {
				printf("bulat\n");
			} else {
				printf("kotak\n");
			}
		} else {
			enqueue(&qpref, mhs);
			enqueue(&qno, tempno);
		}
		if(isEmpty(qpref)) {
			break;
		}
		
		if (isElHomogen(qpref) && isElHomogen(qmakanan)) {

			if (HEAD(qpref) != HEAD(qmakanan)) {
				condition = false;	
			}
		}
		
	}
	printf("%d\n", length(qpref));
	

	return 0;
}